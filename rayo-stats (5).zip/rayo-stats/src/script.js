// Initialisation du site
console.log("Bienvenue sur le site éducatif !");

// Menu de navigation interactif
const navLinks = document.querySelectorAll(".nav-links a");
navLinks.forEach((link) => {
  link.addEventListener("mouseover", () => {
    link.style.color = "#ffcc00";
  });
  link.addEventListener("mouseout", () => {
    link.style.color = "#ffffff";
  });
});

// Section Mathématiques : Démonstrations interactives
const mathDemo = document.getElementById("math-demo");
if (mathDemo) {
  mathDemo.innerHTML = "<h3>Démonstration du Théorème de Pythagore</h3>";

  const canvas = document.createElement("canvas");
  canvas.width = 400;
  canvas.height = 400;
  mathDemo.appendChild(canvas);

  const ctx = canvas.getContext("2d");

  function drawTriangle() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "#007BFF";
    ctx.beginPath();
    ctx.moveTo(50, 350);
    ctx.lineTo(350, 350);
    ctx.lineTo(50, 50);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = "#000";
    ctx.stroke();
  }

  drawTriangle();

  // Ajout d'une calculatrice de l'hypoténuse
  const hypotenuseInput = document.createElement("div");
  hypotenuseInput.innerHTML = `
    <p>Calcul de l'hypoténuse :</p>
    <label for='a'>Côté a :</label>
    <input id='a' type='number' />
    <label for='b'>Côté b :</label>
    <input id='b' type='number' />
    <button id='calculate-hypotenuse'>Calculer</button>
    <p id='result'></p>
  `;
  mathDemo.appendChild(hypotenuseInput);

  document
    .getElementById("calculate-hypotenuse")
    .addEventListener("click", () => {
      const a = parseFloat(document.getElementById("a").value);
      const b = parseFloat(document.getElementById("b").value);
      const result = document.getElementById("result");
      if (!isNaN(a) && !isNaN(b)) {
        result.textContent = `Hypoténuse: ${Math.sqrt(a * a + b * b).toFixed(
          2
        )}`;
      } else {
        result.textContent = "Veuillez entrer des valeurs valides pour a et b.";
      }
    });
}

// Section Physique : Simulations
const physicsDemo = document.getElementById("physics-demo");
if (physicsDemo) {
  physicsDemo.innerHTML = "<h3>Simulation de la chute libre</h3>";

  const startButton = document.createElement("button");
  startButton.textContent = "Lancer la simulation";
  physicsDemo.appendChild(startButton);

  const ball = document.createElement("div");
  ball.style.width = "30px";
  ball.style.height = "30px";
  ball.style.backgroundColor = "red";
  ball.style.borderRadius = "50%";
  ball.style.position = "relative";
  ball.style.top = "0px";
  physicsDemo.appendChild(ball);

  startButton.addEventListener("click", () => {
    let position = 0;
    let speed = 0;
    const gravity = 9.8; // Accélération due à la gravité
    const interval = setInterval(() => {
      speed += gravity * 0.1; // Augmenter la vitesse par pas de temps
      position += speed * 0.1; // Déplacement de la balle
      if (position > 300) {
        clearInterval(interval);
      } else {
        ball.style.top = `${position}px`;
      }
    }, 100);
  });

  // Ajout d'une animation avec un graphique
  const graphCanvas = document.createElement("canvas");
  graphCanvas.width = 400;
  graphCanvas.height = 200;
  physicsDemo.appendChild(graphCanvas);
  const graphCtx = graphCanvas.getContext("2d");

  function drawGraph() {
    graphCtx.clearRect(0, 0, graphCanvas.width, graphCanvas.height);
    graphCtx.beginPath();
    graphCtx.moveTo(0, 200);
    for (let t = 0; t <= 400; t += 10) {
      const y = 200 - gravity * (t / 100) * (t / 100);
      graphCtx.lineTo(t, y);
    }
    graphCtx.strokeStyle = "blue";
    graphCtx.stroke();
  }

  drawGraph();
}

// Section Chimie : Réactions chimiques interactives
const chemistryDemo = document.getElementById("chemistry-demo");
if (chemistryDemo) {
  chemistryDemo.innerHTML = "<h3>Réactions entre l'acide et la base</h3>";

  const acidButton = document.createElement("button");
  acidButton.textContent = "Ajouter Acide";
  chemistryDemo.appendChild(acidButton);

  const baseButton = document.createElement("button");
  baseButton.textContent = "Ajouter Base";
  chemistryDemo.appendChild(baseButton);

  const result = document.createElement("div");
  result.style.marginTop = "20px";
  chemistryDemo.appendChild(result);

  acidButton.addEventListener("click", () => {
    result.textContent = "Ajout d'acide...";
    result.style.color = "red";
  });

  baseButton.addEventListener("click", () => {
    result.textContent = "Ajout de base... Réaction neutre !";
    result.style.color = "blue";
  });

  // Ajout d'une expérience de titrage
  const titrationDiv = document.createElement("div");
  titrationDiv.innerHTML = `
    <p>Simulation de titrage :</p>
    <label for='acid-amount'>Volume d'acide (mL) :</label>
    <input id='acid-amount' type='number' />
    <label for='base-amount'>Volume de base (mL) :</label>
    <input id='base-amount' type='number' />
    <button id='titrate'>Titrer</button>
    <p id='titration-result'></p>
  `;
  chemistryDemo.appendChild(titrationDiv);

  document.getElementById("titrate").addEventListener("click", () => {
    const acid = parseFloat(document.getElementById("acid-amount").value);
    const base = parseFloat(document.getElementById("base-amount").value);
    const result = document.getElementById("titration-result");
    if (!isNaN(acid) && !isNaN(base)) {
      if (acid === base) {
        result.textContent = "Point d'équivalence atteint !";
        result.style.color = "green";
      } else if (acid > base) {
        result.textContent = "Solution acide restante.";
        result.style.color = "red";
      } else {
        result.textContent = "Solution basique restante.";
        result.style.color = "blue";
      }
    } else {
      result.textContent = "Veuillez entrer des volumes valides.";
    }
  });
}

// Section Quiz interactif
const quizSection = document.getElementById("quiz-section");
if (quizSection) {
  quizSection.innerHTML = "<h3>Quiz scientifique</h3>";

  const question = document.createElement("p");
  question.textContent = "Quelle est la vitesse de la lumière dans le vide ?";
  quizSection.appendChild(question);

  const answers = ["3x10^8 m/s", "1.5x10^8 m/s", "300 m/s"];
  answers.forEach((answer) => {
    const button = document.createElement("button");
    button.textContent = answer;
    quizSection.appendChild(button);

    button.addEventListener("click", () => {
      if (answer === "3x10^8 m/s") {
        alert("Correct !");
      } else {
        alert("Incorrect, essayez encore.");
      }
    });
  });
}

// Animations globales
function fadeIn(element, duration = 1000) {
  element.style.opacity = 0;
  element.style.display = "block";
  let opacity = 0;

  const interval = setInterval(() => {
    opacity += 50 / duration;
    if (opacity >= 1) {
      clearInterval(interval);
      opacity = 1;
    }
    element.style.opacity = opacity;
  }, 50);
}

const hiddenSections = document.querySelectorAll(".hidden");
hiddenSections.forEach((section) => {
  setTimeout(() => {
    fadeIn(section);
  }, 500);
});

// Footer : Date dynamique
const footer = document.querySelector("footer p");
if (footer) {
  const currentYear = new Date().getFullYear();
  footer.textContent += ` | © ${currentYear}`;
}
